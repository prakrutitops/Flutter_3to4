<?php
    define('HOST','localhost');
    define('USER','id17629246_practice1');
    define('DB','id17629246_practice');
    define('PASS','Tops@12345678');
    
    $con=mysqli_connect(HOST,USER,PASS,DB) or die('unable to connect');
?>