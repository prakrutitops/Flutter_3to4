import 'package:flutter/material.dart';
import 'package:project456/user/login/Login.dart';
import 'package:project456/user/register/register.dart';
import 'package:project456/user/splashscreen/splash.dart';

void main()
{
  runApp(MaterialApp(home:Login()));
}

